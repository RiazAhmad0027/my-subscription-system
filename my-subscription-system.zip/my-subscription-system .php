<?php
/**
 * Plugin Name: My Subscription System
 * Description: Custom WooCommerce subscription system for learning.
 * Version: 2.0.0
 * Author: Your Name
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
|--------------------------------------------------------------------------
| Check WooCommerce
|--------------------------------------------------------------------------
*/

function mss_check_woocommerce() {

    if ( ! class_exists( 'WooCommerce' ) ) {

        add_action( 'admin_notices', function() {

            echo '<div class="notice notice-error">';
            echo '<p>';
            echo '<strong>My Subscription System:</strong> ';
            echo 'WooCommerce must be installed and activated.';
            echo '</p>';
            echo '</div>';

        } );
    }
}

add_action( 'plugins_loaded', 'mss_check_woocommerce' );


/*
|--------------------------------------------------------------------------
| Register Subscription Product Class
|--------------------------------------------------------------------------
*/

function mss_subscription_product_class(
    $classname,
    $product_type,
    $post_type,
    $product_id
) {

    if ( 'subscription' === $product_type ) {
        $classname = 'MSS_WC_Product_Subscription';
    }

    return $classname;
}

add_filter(
    'woocommerce_product_class',
    'mss_subscription_product_class',
    10,
    4
);


/*
|--------------------------------------------------------------------------
| Custom Subscription Product
|--------------------------------------------------------------------------
*/

if ( class_exists( 'WC_Product_Simple' ) ) {

    class MSS_WC_Product_Subscription extends WC_Product_Simple {

        public function get_type() {
            return 'subscription';
        }

        public function is_purchasable() {

            return (
                $this->exists()
                &&
                'publish' === $this->get_status()
                &&
                '' !== $this->get_price()
            );
        }

        public function add_to_cart_url() {

            return apply_filters(
                'woocommerce_product_add_to_cart_url',
                add_query_arg(
                    'add-to-cart',
                    $this->get_id(),
                    $this->get_permalink()
                ),
                $this
            );
        }

        public function add_to_cart_text() {
            return __( 'Add to cart', 'woocommerce' );
        }

        public function single_add_to_cart_text() {
            return __( 'Add to cart', 'woocommerce' );
        }
    }
}


/*
|--------------------------------------------------------------------------
| Add Subscription Product Type To Product Editor
|--------------------------------------------------------------------------
*/

function mss_add_subscription_product_type( $types ) {

    $types['subscription'] = 'Subscription';

    return $types;
}

add_filter(
    'product_type_selector',
    'mss_add_subscription_product_type'
);


/*
|--------------------------------------------------------------------------
| Subscription Fields
|--------------------------------------------------------------------------
*/

function mss_add_subscription_fields() {

    echo '<div class="options_group show_if_subscription">';


    /*
    | Subscription Price
    */

    woocommerce_wp_text_input(
        array(
            'id'                => '_subscription_price',
            'label'             => 'Subscription Price',
            'description'       => 'Enter the recurring subscription price.',
            'desc_tip'          => true,
            'type'              => 'number',
            'custom_attributes' => array(
                'step' => '0.01',
                'min'  => '0'
            )
        )
    );


    /*
    | Billing Period
    */

    woocommerce_wp_select(
        array(
            'id'          => '_subscription_period',
            'label'       => 'Billing Period',
            'description' => 'Choose how often the subscription renews.',
            'desc_tip'    => true,
            'options'     => array(
                'month' => 'Month',
                'year'  => 'Year'
            )
        )
    );


    echo '</div>';
}

add_action(
    'woocommerce_product_options_general_product_data',
    'mss_add_subscription_fields'
);


/*
|--------------------------------------------------------------------------
| SAVE SUBSCRIPTION PRODUCT
|--------------------------------------------------------------------------
|
| This is the important part.
|
| We save the custom subscription price AND tell WooCommerce
| that this is the actual product price.
|
*/

function mss_save_subscription_product( $product ) {

    if ( ! $product instanceof WC_Product ) {
        return;
    }

    /*
    | Only process Subscription products.
    */

    if ( 'subscription' !== $product->get_type() ) {
        return;
    }


    /*
    | Get subscription price from POST.
    */

    if ( isset( $_POST['_subscription_price'] ) ) {

        $subscription_price = wc_format_decimal(
            wp_unslash( $_POST['_subscription_price'] )
        );

        /*
        | Save our custom subscription price.
        */

        update_post_meta(
            $product->get_id(),
            '_subscription_price',
            $subscription_price
        );


        /*
        | IMPORTANT:
        | Set WooCommerce's actual product price.
        */

        $product->set_regular_price(
            $subscription_price
        );

        $product->set_price(
            $subscription_price
        );
    }


    /*
    | Save Billing Period.
    */

    if ( isset( $_POST['_subscription_period'] ) ) {

        $billing_period = sanitize_text_field(
            wp_unslash( $_POST['_subscription_period'] )
        );

        update_post_meta(
            $product->get_id(),
            '_subscription_period',
            $billing_period
        );
    }


    /*
    | Save the product object.
    */

    $product->save();
}

add_action(
    'woocommerce_admin_process_product_object',
    'mss_save_subscription_product',
    20
);


/*
|--------------------------------------------------------------------------
| Make Sure Subscription Products Have A Price
|--------------------------------------------------------------------------
*/

function mss_subscription_price_filter( $price, $product ) {

    if ( ! $product instanceof WC_Product ) {
        return $price;
    }

    if ( 'subscription' !== $product->get_type() ) {
        return $price;
    }

    $subscription_price = get_post_meta(
        $product->get_id(),
        '_subscription_price',
        true
    );

    if ( '' !== $subscription_price ) {
        return $subscription_price;
    }

    return $price;
}


/*
| Regular price
*/

add_filter(
    'woocommerce_product_get_regular_price',
    'mss_subscription_price_filter',
    10,
    2
);


/*
| Current price
*/

add_filter(
    'woocommerce_product_get_price',
    'mss_subscription_price_filter',
    10,
    2
);


/*
|--------------------------------------------------------------------------
| Subscription Add To Cart
|--------------------------------------------------------------------------
*/

function mss_subscription_add_to_cart() {

    global $product;

    if ( ! $product instanceof WC_Product ) {
        return;
    }


    /*
    | Make sure WooCommerce sees the subscription price.
    */

    $subscription_price = get_post_meta(
        $product->get_id(),
        '_subscription_price',
        true
    );

    if ( '' !== $subscription_price ) {

        $product->set_regular_price(
            $subscription_price
        );

        $product->set_price(
            $subscription_price
        );
    }


    /*
    | Check purchasable.
    */

    if ( ! $product->is_purchasable() ) {
        return;
    }


    /*
    | Check stock.
    */

    if ( ! $product->is_in_stock() ) {
        return;
    }


    /*
    | Use WooCommerce's normal simple product form.
    */

    wc_get_template(
        'single-product/add-to-cart/simple.php'
    );
}

add_action(
    'woocommerce_subscription_add_to_cart',
    'mss_subscription_add_to_cart'
);


/*
|--------------------------------------------------------------------------
| Create Subscription Database Table
|--------------------------------------------------------------------------
*/

function mss_create_subscription_table() {

    global $wpdb;

    $table_name = $wpdb->prefix . 'mss_subscriptions';

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        order_id BIGINT(20) UNSIGNED DEFAULT NULL,
        product_id BIGINT(20) UNSIGNED NOT NULL,
        amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        billing_period VARCHAR(20) NOT NULL DEFAULT 'month',
        status VARCHAR(20) NOT NULL DEFAULT 'active',
        start_date DATETIME NOT NULL,
        next_payment_date DATETIME DEFAULT NULL,
        created_at DATETIME NOT NULL,
        updated_at DATETIME NOT NULL,
        PRIMARY KEY (id),
        KEY user_id (user_id),
        KEY order_id (order_id),
        KEY product_id (product_id),
        KEY status (status)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    dbDelta( $sql );
}

function mss_activate_plugin() {

    mss_create_subscription_table();
}

register_activation_hook(
    __FILE__,
    'mss_activate_plugin'
);


/*
|--------------------------------------------------------------------------
| Create Subscription When Order Becomes Completed
|--------------------------------------------------------------------------
*/

function mss_create_subscription_from_completed_order( $order_id ) {

    global $wpdb;

    $order = wc_get_order( $order_id );

    if ( ! $order ) {
        return;
    }


    /*
    | Customer ID
    */

    $user_id = $order->get_user_id();

    if ( ! $user_id ) {
        return;
    }


    $table_name = $wpdb->prefix . 'mss_subscriptions';


    /*
    | Check every order item.
    */

    foreach ( $order->get_items() as $item ) {

        $product = $item->get_product();

        if ( ! $product ) {
            continue;
        }


        /*
        | Only Subscription products.
        */

        if ( 'subscription' !== $product->get_type() ) {
            continue;
        }


        /*
        | Get subscription price.
        */

        $subscription_price = get_post_meta(
            $product->get_id(),
            '_subscription_price',
            true
        );


        /*
        | Get billing period.
        */

        $billing_period = get_post_meta(
            $product->get_id(),
            '_subscription_period',
            true
        );


        if ( '' === $subscription_price ) {

            $subscription_price = $item->get_total();
        }


        if ( empty( $billing_period ) ) {

            $billing_period = 'month';
        }


        /*
        | Start date.
        */

        $start_timestamp = current_time( 'timestamp' );

        $start_date = wp_date(
            'Y-m-d H:i:s',
            $start_timestamp
        );


        /*
        | Next payment date.
        */

        if ( 'year' === $billing_period ) {

            $next_payment_date = wp_date(
                'Y-m-d H:i:s',
                strtotime(
                    '+1 year',
                    $start_timestamp
                )
            );

        } else {

            $next_payment_date = wp_date(
                'Y-m-d H:i:s',
                strtotime(
                    '+1 month',
                    $start_timestamp
                )
            );
        }


        /*
        | Prevent duplicate records.
        */

        $existing_subscription = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id
                 FROM $table_name
                 WHERE order_id = %d
                 AND product_id = %d
                 LIMIT 1",
                $order_id,
                $product->get_id()
            )
        );


        if ( $existing_subscription ) {
            continue;
        }


        /*
        | Insert subscription.
        */

        $wpdb->insert(
            $table_name,
            array(
                'user_id'           => $user_id,
                'order_id'          => $order_id,
                'product_id'        => $product->get_id(),
                'amount'            => $subscription_price,
                'billing_period'    => $billing_period,
                'status'            => 'active',
                'start_date'        => $start_date,
                'next_payment_date' => $next_payment_date,
                'created_at'        => $start_date,
                'updated_at'        => $start_date,
            ),
            array(
                '%d',
                '%d',
                '%d',
                '%f',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s'
            )
        );
    }
}

add_action(
    'woocommerce_order_status_completed',
    'mss_create_subscription_from_completed_order'
);
// 1. Wait until WooCommerce loads completely before declaring the class
add_action( 'plugins_loaded', 'init_premium_subscription_product' );

function init_premium_subscription_product() {
    if ( ! class_exists( 'WC_Product' ) ) {
        return;
    }

    class WC_Product_Premium_Subscription extends WC_Product {
        public function __construct( $product ) {
            $this->product_type = 'premium_subscription';
            parent::__construct( $product );
        }

        // Force WooCommerce to know this product is buyable
        public function is_purchasable() {
            return true;
        }

        // Force it to register as in stock
        public function is_in_stock() {
            return true;
        }

        // Bypasses empty price hiding mechanisms by hardcoding a value
        public function get_price( $context = 'view' ) {
            return '10'; 
        }
        
        public function get_regular_price( $context = 'view' ) {
            return '10';
        }
    }
}

// 2. Map the product type to your class name
add_filter( 'woocommerce_product_class', 'register_premium_subscription_product_class', 10, 2 );
function register_premium_subscription_product_class( $classname, $product_type ) {
    if ( $product_type === 'premium_subscription' ) {
        $classname = 'WC_Product_Premium_Subscription';
    }
    return $classname;
}

// 3. Fallback globally to tell WooCommerce this type is buyable
add_filter( 'woocommerce_is_purchasable', 'force_premium_sub_purchasable', 10, 2 );
function force_premium_sub_purchasable( $is_purchasable, $product ) {
    if ( is_object( $product ) && $product->get_type() === 'premium_subscription' ) {
        return true;
    }
    return $is_purchasable;
}

// 4. Force inject the "Add to Cart" template layout manually
add_action( 'woocommerce_single_product_summary', 'inject_premium_subscription_cart_button', 30 );
function inject_premium_subscription_cart_button() {
    global $product;
    if ( is_object( $product ) && $product->get_type() === 'premium_subscription' ) {
        wc_get_template( 'single-product/add-to-cart/simple.php' );
    }
}
